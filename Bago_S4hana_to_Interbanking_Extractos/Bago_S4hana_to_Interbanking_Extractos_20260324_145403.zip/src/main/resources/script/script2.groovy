import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {

    String body = message.getBody(String)

    if (!body) {
        return message
    }

    // --------------------------------------------------
    // 1️⃣ Quitar prefijo p2
    // --------------------------------------------------
    body = body
        .replaceAll("<p2:", "<")
        .replaceAll("</p2:", "</")
        .replaceAll('xmlns:p2="http://bago.extractos.soap"', 'xmlns="http://bago.extractos.soap"')

    // --------------------------------------------------
    // 2️⃣ Asegurar 'Z' en dateTime (si no la tiene)
    // --------------------------------------------------
    body = body.replaceAll(
        /(<(row_date|movement_date|real_date_activity|process_date|value_date)>[0-9T:\.-]+)(<\/\2>)/,
        { full, value, tag, close ->
            value.endsWith("Z") ? full : value + "Z" + close
        }
    )

    // --------------------------------------------------
    // 3️⃣ Si <statements/> viene vacío → inyectar estructura completa
    // --------------------------------------------------
    if (body.contains("<statements/>")) {

        body = body.replace(
            "<statements/>",
            """<statements>
                <total_movements>0</total_movements>
                <operation_date>1970-01-01</operation_date>
                <statement_number>0</statement_number>
                <ending_balance>0</ending_balance>
                <opening_balance>0</opening_balance>
                <debits_total_amount>0</debits_total_amount>
                <credits_total_amount>0</credits_total_amount>
                <movement_detail>
                    <operation_code_ib>0</operation_code_ib>
                    <operation_code_bank>0</operation_code_bank>
                    <code_description_ib>0</code_description_ib>
                    <customer_cuit>0</customer_cuit>
                    <depositor_description>0</depositor_description>
                    <code_description_bank>0</code_description_bank>
                    <movement_date>1970-01-01T00:00:00Z</movement_date>
                    <real_date_activity>1970-01-01T00:00:00Z</real_date_activity>
                    <amount>0</amount>
                    <voucher_number>0</voucher_number>
                    <branch_office_activity>0</branch_office_activity>
                    <process_date>1970-01-01T00:00:00Z</process_date>
                    <value_date>1970-01-01T00:00:00Z</value_date>
                    <debit_credit_type>0</debit_credit_type>
                    <correlative_number>0</correlative_number>
                </movement_detail>
            </statements>"""
        )
    }

    // --------------------------------------------------
    // 4️⃣ Tags NO fecha vacíos → poner 0
    // --------------------------------------------------
    body = body.replaceAll(
        /<([a-zA-Z_]+)\/>/,
        { full, tag ->
            // excluir fechas
            if (tag in [
                'row_date',
                'movement_date',
                'real_date_activity',
                'process_date',
                'value_date',
                'operation_date'
            ]) {
                return "<${tag}>1970-01-01</${tag}>"
            } else {
                return "<${tag}>0</${tag}>"
            }
        }
    )

    message.setBody(body)
    return message
}