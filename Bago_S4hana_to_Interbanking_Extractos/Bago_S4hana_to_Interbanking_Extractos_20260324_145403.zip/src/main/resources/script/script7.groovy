/* Refer the link below to learn more about the use cases of script.
https://help.sap.com/viewer/368c481cd6954bdfa5d0435479fd4eaf/Cloud/en-US/148851bf8192412cba1f9d2c17f4bd25.html

If you want to know more about the SCRIPT APIs, refer the link below
https://help.sap.com/doc/a56f52e1a58e4e2bac7f7adbf45b2e26/Cloud/en-US/index.html */
import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {

     def headers = message.getHeaders()
    def cuentaId = headers.get("cuenta-id")?.toString()?.trim()

    if (!cuentaId) {
        throw new Exception("Header 'cuenta-id' no encontrado o vacío")
    }

    // Leer URL base desde property externalizado
    def props = message.getProperties()
    def urlBase = props.get("URL_INTERBANKING")?.toString()?.trim()

    if (!urlBase) {
        throw new Exception("Property 'URL_INTERBANKING' no encontrada")
    }

    // Asegurar que la URL base termine con /
    if (!urlBase.endsWith("/")) {
        urlBase = urlBase + "/"
    }

    // Armar URL completa
    def urlCompleta = urlBase + cuentaId + "/statements"

    // Guardar en header para que el adapter HTTP la use
    message.setHeader("urlCompleta", urlCompleta)

    // O bien sobreescribir directamente el property
    message.setProperty("URL_INTERBANKING", urlCompleta)

    return message
}