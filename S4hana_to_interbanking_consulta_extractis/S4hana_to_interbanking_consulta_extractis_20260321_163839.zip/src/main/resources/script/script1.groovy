import com.sap.gateway.ip.core.customdev.util.Message;
import com.sap.it.api.ITApiFactory;
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.exception.SecureStoreException

def Message processData(Message message) {
    
    map = message.getProperties();
    def secure_client_id = map.get("SECURE_CLIENT_ID");
    
    // read the credentials
    def secureStoreService = ITApiFactory.getApi(SecureStoreService.class, null)
    def userCredJwt = secureStoreService.getUserCredential(secure_client_id.toString()) 
    String clientid = userCredJwt.getUsername();
 
    
    //map = message.getProperties();
    //def nameMaterialSecure = map.get("SECURE_CLIENT_ID");
    //def secureStorageService =  ITApiFactory.getService(SecureStoreService.class, null)
    try{
        //def secureParameter = secureStorageService.getUserCredential(nameMaterialSecure.toString())
        message.setHeader("client_id", clientid)
    } catch(Exception e){
        throw new SecureStoreException("Secure Parameter not available")
    }
    return message;

    
}
